try{window.localStorage.removeItem('google_pub_config');}catch(e){}
